import React from 'react';
class Hello extends React.Component {
    render() {
                return(
                    <div className="Hello">
                        <label for="hello"> 안녕하세요!</label>
                    </div>
                );
    }
}
export default Hello;